function fdtd1D()


global eps0 mu0 imp0 c nm fs
eps0 = 8.8541878176209821e-12;
mu0  = 1.2566370614359173e-06;
imp0 = sqrt(mu0/eps0);
% c    = 299792458; % 1/sqrt(eps0*mu0)
c    = 1/sqrt(eps0*mu0);
nm   = 1e-9;
fs   = 1e-15;


isWaterFall = true;
% isWaterFall = false;

sourceR.ppw         = 20;
sourceR.omega       = 300e12; % 300/1micron = 300THz
sourceR.timeDelay	= sourceR.ppw;
sourceR.Type        = 'Ricker';
sourceR.isAdd       = true;
% sourceR.isAdd     = false;

sourceG.ppw         = 20;
sourceG.timeDelay	= 4*sourceG.ppw;
sourceG.Type        = 'gauss';
sourceG.isAdd       = true;
% sourceG.isAdd       = false;

source = sourceR;
% source = sourceG;

PML = [];
TFSFregion = [];

% FileName = 'init.dat';
% loadDataFromFile(FileName);

MaxTime = 1000; % duration of simulation

additiveSource = 50;
% additiveSource = 3;

%% initialization
domainSize = 200; % x size of domain
FDTDregion = [0,400*nm];
PML = struct('layers',10, 'm',3.5, 'coef',0.8);
calFDTD = FDTD(domainSize,FDTDregion,PML);       % creat 1D FDTD grid (isTE for 2D)
calFDTD.initGrid([],[]);                    % initialize the 1D FDTD grid
if isempty(PML)
    calFDTD.initABC('2abc');                % initialize ABC
end
TFSFregion = [10;domainSize-10];
if ~isempty(TFSFregion)
    calFDTD.initTFSF(TFSFregion,source);        % initialize TFSF
end

% graphic output initialization
x  = calFDTD.getGridXYZ('Ez')/nm; % in nm
dt = calFDTD.get_dt()/fs; % in fs
figure;
if isWaterFall
    waterfall(x,0,calFDTD.snapshotE('z').');
else
    plot3(x,0*ones(1,domainSize),calFDTD.snapshotE().','color','blue');
end
hf = gca; hold on
view(-20,62)
xlabel('x, nm')
ylabel('Time, fs')
%zlabel('Electric field')


% do time stepping
for n_time = 1:MaxTime
    calFDTD.updateH();          % update magnetic field
    if isempty(TFSFregion)
        calFDTD.add_Hy_inc(additiveSource-1, n_time-1, source); % add a source
    else
        calFDTD.updateTFSF(n_time);	% apply TFSF boundary
    end
    calFDTD.updateE();          % update electric field
    if isempty(TFSFregion)
        calFDTD.add_Ez_inc(additiveSource, n_time, source); % add a source
    end
    if isempty(PML)
        calFDTD.applyABC();         % apply ABC
    end

    if mod(n_time,10)==0
        if isWaterFall
            waterfall(hf,x,n_time*dt,calFDTD.snapshotE().');
        else
            plot3(hf,x,n_time*ones(1,domainSize)*dt,calFDTD.snapshotE('z').','color','blue');
        end
    end
    
end % of time-stepping
 
end

